#include <stdio.h>

int main()
{
    int values[8] = {128, 64, 32, 16, 8, 4, 2, 1};
    int decimal = 224;
    int index = 0;
    int binary;
    while (index < 8)
    {
        if (decimal >= values[index])
        {
            decimal = decimal - values[index];
            binary = 1;
        }
        else
            binary = 0;
        printf("%d", binary);
        index++;
    }
    return 0;
}

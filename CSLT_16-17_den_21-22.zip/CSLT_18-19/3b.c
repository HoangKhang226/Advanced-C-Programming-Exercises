#include <stdio.h>
int output(int messages)
{
    int fee = 50000;
    if (messages <= 100)
        return fee;
    else if (messages <= 200)
        return fee + (messages - 100) * 300;
    else
        return fee + (200 - 100) * 300 + (messages - 200) * 400;
}
int main()
{
    int messages;
    printf("Nhap so tin nhan cua thue bao (Nhap 0 de ket thuc): ");
    scanf("%d", &messages);
    while (messages != 0)
    {
        printf("Phi thue bao phai tra: %d dong\n", output(messages));
        printf("Nhap so tin nhan cua thue bao (Nhap 0 de ket thuc): ");
        scanf("%d", &messages);
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int messages;
    int fee = 50000;
    printf("Nhap so tin nhan da gui: ");
    scanf("%d", &messages);
    if (messages <= 100)
    {
        printf("Tong phi phai tra la: %d dong\n", fee);
    }
    else if (messages <= 200)
    {
        fee += (messages - 100) * 300;
        printf("Tong phi phai tra la: %d dong\n", fee);
    }
    else
    {
        fee += (200 - 100) * 300 + (messages - 200) * 400;
        printf("Tong phi phai tra la: %d dong\n", fee);
    }
    return 0;
}

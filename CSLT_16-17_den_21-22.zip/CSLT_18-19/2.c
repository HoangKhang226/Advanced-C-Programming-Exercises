#include <stdio.h>
int main()
{
    int n;
    printf("nhap kich thuoc cho ma tran vuong: ");
    scanf("%d", &n);
    printf("nhap ma tran:\n");
    int a[100][100];
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            scanf("%d",&a[i][j]);
    int flag = 1;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
            if (a[i][j] != a[j][i])
            {
                flag = 0;
                break;
            }
        if (!flag)
            break;
    }
    if (flag)
        printf("ma tran doi xung qua duong cheo chinh");
    else
        printf("ma tran khong doi xung qua duong cheo chinh");
    return 0;
}
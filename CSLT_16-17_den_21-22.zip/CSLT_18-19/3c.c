#include <stdio.h>
int input_messages()
{
    int messages;
    printf("Nhap so tin nhan cua thue bao: ");
    scanf("%d", &messages);
    return messages;
}
int calculate_fee(int messages)
{
    int fee = 50000;
    if (messages <= 100)
        return fee;
    else if (messages <= 200)
        return fee + (messages - 100) * 300;
    else
        return fee + (200 - 100) * 300 + (messages - 200) * 400;
}
int main()
{
    int messages;
    printf("Nhap so tin nhan cua thue bao (Nhap 0 de ket thuc): ");
    scanf("%d", &messages);
    while (messages != 0)
    {
        int fee = calculate_fee(messages);
        printf("Phi thue bao phai tra: %d dong\n", fee);
        printf("Nhap so tin nhan cua thue bao (Nhap 0 de ket thuc): ");
        scanf("%d", &messages);
    }
    return 0;
}

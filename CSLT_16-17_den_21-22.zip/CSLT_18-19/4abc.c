#include <stdio.h>
#include <string.h>
void inputStates(char states[][80], int n)
{
    printf("Nhap ten cac tieu bang:\n");
    for (int i = 0; i < n; i++)
    {
        printf("Tieu bang %d: ", i + 1);
        gets_s(states[i], sizeof(states[i]));
    }
}
void inputAbbreviation(char abbr[][3], int n)
{
    printf("Nhap viet tat cua cac tieu bang:\n");
    for (int i = 0; i < n; i++)
    {
        printf("Viet tat cho tieu bang %d: ", i + 1);
        gets_s(abbr[i], sizeof(abbr[i]));
    }
}
char *lookup(char *s, char abbr[][3], char states[][80], int n)
{
    for (int i = 0; i < n; i++)
        if (strcmp(abbr[i], s) == 0)
            return states[i];
    return NULL;
}
int main()
{
    int n;
    printf("Nhap so luong tieu bang: ");
    scanf("%d", &n);
    getchar();
    char states[100][80]; // Mảng lưu tên tiểu bang
    char abbr[100][3];    // Mảng lưu viết tắt của tiểu bang
    // Nhập tên tiểu bang và viết tắt
    inputStates(states, n);
    inputAbbreviation(abbr, n);
    char search_abbr[3];
    printf("Nhap viet tat de tra cuu: ");
    gets_s(search_abbr, sizeof(search_abbr));
    char *res = lookup(search_abbr, abbr, states, n);
    if (res == NULL)
        printf("khong tim thay");
    else
        printf("%s", res);
    return 0;
}

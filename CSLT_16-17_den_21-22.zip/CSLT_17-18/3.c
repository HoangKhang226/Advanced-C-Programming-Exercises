#include <stdio.h>
int check(char *a, char *b)
{
    int count1 = 0, count2 = 0;
    while (a[count1] != '\0')
        count1++;
    while (b[count2] != '\0')
        count2++;
    if (count1 != count2)
        return 0;
    for (int i = 0; i < count1; i++)
        if (a[i] != b[i])
            return 0;
    return 1;
}
int main()
{
    char a[100], b[100];
    gets_s(a, sizeof(a));
    gets_s(b, sizeof(b));
    int res = check(a, b);
    if (res)
        printf("giong nhau");
    else
        printf("khac nhau");
    return 0;
}
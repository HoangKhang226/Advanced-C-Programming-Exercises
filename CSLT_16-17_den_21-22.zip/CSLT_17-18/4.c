#include <stdio.h>
void input(char s[100][100], int *n)
{
    printf("nhap so chuoi: ");
    scanf("%d", n); // lí do không dùng & vì khi truyền n vào hàm thì ta đang truyền con trỏ, nghĩa là nó chính là địa chỉ của n
    getchar();
    for (int i = 0; i < *n; i++)
        gets_s(s[i], sizeof(s[i]));
}
char *getString(char s[100][100], int index) // dùng char * vì chuỗi và mảng khi trả về là trả về địa chỉ, chứ k phải giá trị
{
    return s[index - 1]; // Trả về chuỗi tương ứng với chỉ số (lưu ý chỉ số nhập từ 1)
}
int main()
{
    char s[100][100];
    int n;
    // lưu ý khi làm việc với chuỗi
    //  nếu trước khi khai báo chuỗi có dùng hàm scanf, thì cần dùng thêm hàm getchar để xóa kí tự \n
    input(s, &n); // chuỗi và mảng là con trỏ sẵn, nên không cần &s
    printf("nhap 1 so trong khoang tu 1 den %d: ", n);
    scanf("%d", &n);
    getchar();
    char *p = getString(s, n );
    printf("%s", p);
    return 0;
}
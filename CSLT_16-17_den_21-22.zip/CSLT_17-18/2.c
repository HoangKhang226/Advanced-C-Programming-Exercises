#include <stdio.h>
int main()
{
    int a[6] = {0}, i = 1;
    while (1)
    {
        int n;
        printf("nhap so nguoi phu thuoc nhan vien thu %d: ", i++);
        scanf("%d", &n);
        if (n < 0 || n > 5)
            break;
        a[n]++;
    }
    printf("so nguoi phu thuoc  |   so luong nhan vien");
    for (i = 0; i < 6; i++)
    {
        printf("\n        %d           |             %d", i, a[i]);
    }
    return 0;
}
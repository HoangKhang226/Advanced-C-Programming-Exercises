#include <stdio.h>
int main() {
    int n;
    scanf("%d",&n);
    if(n<=10)
    printf("muc do khuyen mai la: 0%%\n");//chú ý kí tự phần trăm k thể in được nên phải dùng %% để in ra %
    else if(n<=24)
    printf("muc do khuyen mai la: 5%%\n");
    else if(n<=50)
    printf("muc do khuyen mai la: 10%%\n");
    else
    printf("muc do khuyen mai la: 15%%\n");
    return 0;
}
#include <stdio.h>
void strCat(char *dest, char *src)
{
    while (*dest != '\0') // dịch chuyển con trỏ đến vị trí cuối cùng của chuỗi dst
        dest++;
    while (*src != '\0') // Nối chuỗi src vào sau chuỗi dest
    {
        *dest = *src;
        dest++;
        src++;
    }
    // Thêm ký tự kết thúc chuỗi '\0' vào cuối chuỗi dest
    *dest = '\0'; // hiện tại vị trí của dest đang ở cuỗi phần từ
    // nếu muốn in ra chuỗi thì trước khi di chuyển đến vị trí cuối cùng của chuỗi phải thêm char *originaldest=dest;
    // khi khai báo như v thì chuỗi con trỏ original đang trỏ vào vị trí đầu tiên của chuỗi dest
    // sau đó in ra chuỗi bằng printf("%s",originaldest);
}
int main()
{
    char dest[100], src[100];
    gets_s(dest, sizeof(dest));
    gets_s(src, sizeof(src));
    strCat(dest, src);
    return 0;
}
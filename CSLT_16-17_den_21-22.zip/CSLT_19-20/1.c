#include <stdio.h>
#include <math.h>
int main()
{
    int n, a[100];
    printf("nhap so phan tu cua mang: ");
    scanf("%d", &n);
    printf("nhap mang: ");
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    int count = 0;
    for (int i = 0; i < n; i++)
    {
        int flag = 1;
        if (a[i] < 2)
            flag = 0;
        else
            for (int j = 2; j <= sqrt(a[i]); j++)
                if (a[i] % j == 0)
                    flag = 0;
        if (a[i] < 2)
            flag = 0;
        if (flag)
            count++;
    }
    printf("so phan tu la SNT trong mang la: %d", count);
    return 0;
}
#include <stdio.h>
void nhapmang(int *a, int n)
{
    printf("nhap mang: ");
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);
}
void soxuathiennhieunhat(int *a, int n)
{
    int tansuat[11] = {0};
    for (int i = 0; i < n; i++)
        tansuat[a[i]]++;
    int max = tansuat[0], pos = 0;
    for (int i = 1; i < 11; i++)
        if (tansuat[i] > max)
            max = tansuat[i], pos = i;
    printf("so %d xuat hien nhieu nhat la %d\n", pos,max);
}
int main()
{
    int n, a[100];
    printf("nhap so phan tu cua mang: ");
    scanf("%d", &n);
    nhapmang(a, n);
    soxuathiennhieunhat(a, n);
}
#include <stdio.h>
#include <math.h>
int main()
{
    int n, a[100];
    printf("nhap so phan tu cua mang: ");
    scanf("%d", &n);
    printf("nhap mang: ");
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("nhap x:");
    float x;
    scanf("%f", &x);
    float min = fabs(a[0] - x);
    int pos = 0;

    for (int i = 1; i < n; i++)
    {
        float y = fabs(a[i] - x);
        if (y < min)
        {
            min = y;
            pos = i;
        }
    }
    printf("%d", a[pos]);
    return 0;
}
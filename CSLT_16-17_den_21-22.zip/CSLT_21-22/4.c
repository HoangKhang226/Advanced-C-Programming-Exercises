#include <stdio.h>
int size_of_string(char *s);
void delete_space_in_begin_and_end_of_string(char *s);
void delete_space_inside_of_string(char *s);
void upper_and_lower_inside_string(char *s);
int main()
{
    char original_s[50], s[50];
    gets_s(original_s, sizeof(original_s));
    int i = 0;
    while (original_s[i] != '\0')
    {
        s[i] = original_s[i];
        i++;
    }
    s[i] = '\0';
    delete_space_in_begin_and_end_of_string(s);
    delete_space_inside_of_string(s);
    upper_and_lower_inside_string(s);
    printf("%s", s);
}
int size_of_string(char *s)
{
    int count = 0;
    while (s[count] != '\0')
    {
        count++;
    }
    return count;
}
void delete_space_in_begin_and_end_of_string(char *s)
{
    int size = size_of_string(s);
    while (1)
    {
        if ((s[size] >= 'a' && s[size] <= 'z') || (s[size] >= 'A' && s[size] <= 'Z'))
        {
            s[size + 1] = '\0';
            size++;
            break;
        }
        size--;
    }
    int count = 0;
    for (int i = 0; i < size; i++)
    {
        if ((s[i] >= 'a' && s[i] <= 'z') || (s[i] >= 'A' && s[i] <= 'Z'))
            break;
        count++;
    }
    for (int j = 0; j < size; j++)
        s[j] = s[j + count];
}
void delete_space_inside_of_string(char *s)
{
    int size = size_of_string(s), i = 0;
    while (s[i] != '\0')
    {
        if (s[i] == ' ' && s[i + 1] == ' ')
        {
            for (int j = i + 1; j < size; j++)
                s[j] = s[j + 1];
            i--;
        }
        i++;
    }
}
void upper_and_lower_inside_string(char *s)
{
    int size = size_of_string(s);
    for (int i = 0; i < size; i++)
    {
        if (i == 0)
        {
            if (s[i] >= 'a' && s[i] <= 'z')
                s[i] -= 32;
        }
        else if (s[i - 1] == ' ' && s[i] >= 'a' && s[i] <= 'z')
            s[i] -= 32;
        else
        {
            if (s[i] >= 'A' && s[i] <= 'Z')
                s[i] += 32;
        }
    }
}

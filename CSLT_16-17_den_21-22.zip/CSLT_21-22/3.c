#include <stdio.h>
void nhap_vector(float *vec, int n)
{
    for (int i = 0; i < n; i++)
    {
        printf("Nhap phan tu thu %d: ", i + 1);
        scanf("%f", &vec[i]);
    }
}
float tinh_tich_vo_huong(float *vec1, float *vec2, int n)
{
    float tich = 0;
    for (int i = 0; i < n; i++)
        tich += vec1[i] * vec2[i];
    return tich;
}
int main()
{
    int n;
    printf("Nhap chieu dai cua vector: ");
    scanf("%d", &n);
    float vec1[100], vec2[100];
    printf("Vector 1:\n");
    nhap_vector(vec1, n);
    printf("Vector 2:\n");
    nhap_vector(vec2, n);
    float res= tinh_tich_vo_huong(vec1, vec2, n);
    printf("Tich vo huong cua hai vector la: %.2f\n",res);
    return 0;
}

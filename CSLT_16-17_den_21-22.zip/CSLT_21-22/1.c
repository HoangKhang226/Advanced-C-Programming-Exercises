#include <stdio.h>
#include <math.h>
int main()
{
    float a[100][2];
    int n;
    printf("nhap so diem: ");
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
        scanf("%f%f", &a[i][0], &a[i][1]);
    float sum = 0;
    for (int i = 0, j = 1; i < n - 1; i++, j++)
        sum += sqrt((a[i][0] - a[j][0]) * (a[i][0] - a[j][0]) + (a[i][1] - a[j][1]) * (a[i][1] - a[j][1]));
    printf("%.2f", sum);
    return 0;
}
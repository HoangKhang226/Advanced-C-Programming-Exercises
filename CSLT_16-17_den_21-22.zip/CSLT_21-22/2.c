#include <stdio.h>
int main()
{
    float n;
    int tansuat[41] = {0};
    scanf("%f", &n);
    while (n >= 0)
    {
        int x = n * 2;
        tansuat[x]++;
        scanf("%f", &n);
    }
    for (int j = 0; j <= 20; j++)
        printf("co %d diem %.1f\n", tansuat[j], (float)j / 2);
    return 0;
}
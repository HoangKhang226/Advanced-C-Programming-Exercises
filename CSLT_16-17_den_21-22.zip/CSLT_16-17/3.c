#include <stdio.h>
#include <string.h>
int main()
{
    // mảng chuỗi 3 chiều
    char courses[4][2][50] = {
        {"MTH00055", "Co so lap trinh"},
        {"TTH105", "Toan roi rac"},
        {"TTH802", "Mang may tinh"},
        {"TTH573", "Lap trinh Web"}};
    char ma_mon[50];
    gets_s(ma_mon, sizeof(ma_mon));
    for (int i = 0; i < 4; i++)
        if (strcmp(courses[i][0], ma_mon) == 0)
            printf("ten mon hoc tuong ung la: %s\n", courses[i][1]);
    return 0;
    //     Mảng 3 chiều courses[4][2][50] được hiểu là:
    // 4: Số lượng dòng, mỗi dòng đại diện cho một môn học.
    // 2: Mỗi dòng có 2 chuỗi (mã môn học và tên môn học).
    // 50: Kích thước tối đa của mỗi chuỗi.
}
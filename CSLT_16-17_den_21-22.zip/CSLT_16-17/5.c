#include <stdio.h>
void daonguocchuoi(char *s)
{
    for (int i = 0,j=strlen(s)-1; i < j; i++, j--)
    {
        char temp[2];
        temp[0] = s[i];
        s[i] = s[j];
        s[j] = temp[0];
    }
}
int main()
{
    char s[100];
    gets_s(s, sizeof(s));
    daonguocchuoi(s);
    printf("%s", s);
    return 0;
}
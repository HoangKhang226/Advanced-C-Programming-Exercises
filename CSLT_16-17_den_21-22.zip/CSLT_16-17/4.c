#include <stdio.h>
int main()
{
    int a[100], n;
    printf("nhap so phan tu cua mang: ");
    scanf("%d", &n);
    printf("nhap mang: ");
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    // tính tổng mảng
    float tong = 0;
    for (int i = 0; i < n; i++)
        tong += a[i];
    float mean = tong / n;
    int count = 0;
    for (int i = 0; i < n; i++)
        if (a[i] > mean)
            count++;
    printf("trung binh cua mang tren la: %.2f\n", mean);
    printf("so phan tu lon hon trung binh la: %d", count);
    return 0;
}
#include <stdio.h>
int main()
{
    int n;
    printf("nhap thu thap ca nhan: ");
    scanf("%d", &n);
    if (n <= 10000000)
        printf("mien thue");
    else if (n <= 15000000)
        printf("thue thu thap ca nhan: %.0f ngan dong", (n - 10000000) * 0.05);
    else if (n <= 20000000)
        printf("thue thu thap ca nhan: %.0f ngan dong", 5000000 * 0.05 + (n - 15000000) * 0.1);
    else
        printf("thue thu thap ca nhan: %.0f ngan dong", 5000000 * 0.05 + 5000000 * 0.1 + (n - 20000000) * 0.15);
    return 0;
}
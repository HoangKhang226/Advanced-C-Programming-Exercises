#include <stdio.h>
int main()
{
    char s[100];
    gets_s(s, sizeof(s));
    int count = 0;
    while (s[count] != '\0')
        s[count++];
    int sum = 0;
    for (int i = 0; i < count; i++)
    {
        if (s[i] == '1')
            sum = sum * 2 + 1;
        else
            sum = sum * 2;
    }
    printf("%d", sum);
    return 0;
}